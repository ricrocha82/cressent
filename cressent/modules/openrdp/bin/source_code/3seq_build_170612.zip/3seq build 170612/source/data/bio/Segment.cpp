/**
 * Copyright (c) 2006-09 Maciej F. Boni.  All Rights Reserved.
 * 
 * FILE NAME:   Segment.cpp
 * CREATED ON:  28 July 2011, 11:28
 * AUTHOR:      Maiej F. Boni, Ha Minh Lam
 * 
 * DESCRIPTION: 
 * 
 * HISTORY:     Version     Date        Description
 *              1.0         2011-07-28  Created
 * 
 * VERSION:     1.0
 * LAST EDIT:   28 July 2011
 */

#include "Segment.h"

//Segment::Segment(const string& segmentStr, const string& newName) 
//: Sequence(segmentStr, newName) {
//}

//Segment::~Segment() {
//}

